array = input("Ingrese el arreglo: ");
deviation = std_dev(array);

fprintf("La desviación estandar del arreglo es %d.\n", deviation);